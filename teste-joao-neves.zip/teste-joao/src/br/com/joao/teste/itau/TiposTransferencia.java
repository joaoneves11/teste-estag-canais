package br.com.joao.teste.itau;

public enum TiposTransferencia {

	PIX, TED, DOC;
	
}
